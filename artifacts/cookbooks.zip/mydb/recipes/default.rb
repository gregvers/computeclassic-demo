#
# Cookbook:: mydb
# Recipe:: default
#
# Copyright:: 2017, The Authors, All Rights Reserved.

include_recipe "mongodb3::default"

